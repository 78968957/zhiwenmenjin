function dd=juli(x11,y11,x12,y12)
dd=sqrt((x11-x12)^2+(y11-y12)^2);